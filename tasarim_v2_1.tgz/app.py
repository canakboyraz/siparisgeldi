﻿"""Uygulama fabrikası (application factory)."""
import secrets

from flask import Flask, abort, request, session
from werkzeug.middleware.proxy_fix import ProxyFix
from sqlalchemy import text

from config import Config
from extensions import db, login_manager


def _ensure_schema():
    """Mevcut veritabanlarina sonradan eklenen kolonlari guvenle ekler."""
    # Reklam gideri modeli daha sonra eklendi; eski ortamlarda tabloyu acikca
    # kontrol ederek uygulama baslangicinda hazir oldugundan emin ol.
    from models import DailyAdvertisingExpense
    DailyAdvertisingExpense.__table__.create(bind=db.engine, checkfirst=True)
    backend = db.engine.url.get_backend_name()

    if backend.startswith("postgres"):
        stmts = [
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_number VARCHAR(30)",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS notification_channel VARCHAR(20) DEFAULT 'telegram'",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_last_status VARCHAR(30)",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_last_status_at TIMESTAMP",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_last_message_id VARCHAR(200)",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS whatsapp_last_error VARCHAR(300)",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS order_popup_sound_enabled BOOLEAN DEFAULT FALSE",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS order_popup_sound VARCHAR(20) DEFAULT 'classic'",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS receipt_width VARCHAR(10) DEFAULT '80mm'",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS feature_whatsapp BOOLEAN DEFAULT FALSE",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS feature_multi_platform BOOLEAN DEFAULT FALSE",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS pro_started_at TIMESTAMP",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS pro_expires_at TIMESTAMP",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS pro_expiry_notice_sent_on DATE",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMP",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_trial BOOLEAN DEFAULT FALSE",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS tgo_store_id VARCHAR(50)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS migros_group_id VARCHAR(50)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS migros_warehouse_id VARCHAR(50)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS getir_restaurant_id VARCHAR(50)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS getir_restaurant_name VARCHAR(120)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS getir_restaurant_secret_key VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS tmp_supplier_id VARCHAR(50)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS tmp_integration_ref VARCHAR(120)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS tmp_api_key VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS tmp_api_secret VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS hb_merchant_id VARCHAR(80)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS hb_username VARCHAR(120)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS hb_service_key VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS hb_environment VARCHAR(20) DEFAULT 'live'",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS hb_auto_packaging BOOLEAN DEFAULT FALSE",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_chain_id VARCHAR(100)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_store_id VARCHAR(100)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_vendor_id VARCHAR(100)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_environment VARCHAR(20) DEFAULT 'live'",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_client_id VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS ys_client_secret VARCHAR(512)",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS notify_weekly_report BOOLEAN DEFAULT TRUE",
            "ALTER TABLE integrations ADD COLUMN IF NOT EXISTS notify_monthly_report BOOLEAN DEFAULT TRUE",
            "ALTER TABLE platform_expenses ADD COLUMN IF NOT EXISTS expense_type VARCHAR(20) DEFAULT 'fixed'",
            "ALTER TABLE orders ADD COLUMN IF NOT EXISTS active_hidden_at TIMESTAMP",
            """
            CREATE UNIQUE INDEX IF NOT EXISTS uq_migros_store_id
            ON integrations (migros_store_id)
            WHERE platform = 'migros' AND migros_store_id IS NOT NULL
            """,
        ]
    elif backend.startswith("sqlite"):
        with db.engine.begin() as conn:
            user_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(users)")).fetchall()}
            intg_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(integrations)")).fetchall()}
            stmts = []
            if "whatsapp_number" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN whatsapp_number VARCHAR(30)")
            if "notification_channel" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN notification_channel VARCHAR(20) DEFAULT 'telegram'")
            if "whatsapp_last_status" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN whatsapp_last_status VARCHAR(30)")
            if "whatsapp_last_status_at" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN whatsapp_last_status_at DATETIME")
            if "whatsapp_last_message_id" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN whatsapp_last_message_id VARCHAR(200)")
            if "whatsapp_last_error" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN whatsapp_last_error VARCHAR(300)")
            if "order_popup_sound_enabled" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN order_popup_sound_enabled BOOLEAN DEFAULT FALSE")
            if "order_popup_sound" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN order_popup_sound VARCHAR(20) DEFAULT 'classic'")
            if "receipt_width" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN receipt_width VARCHAR(10) DEFAULT '80mm'")
            if "feature_whatsapp" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN feature_whatsapp BOOLEAN DEFAULT FALSE")
            if "feature_multi_platform" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN feature_multi_platform BOOLEAN DEFAULT FALSE")
            if "pro_started_at" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN pro_started_at DATETIME")
            if "pro_expires_at" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN pro_expires_at DATETIME")
            if "pro_expiry_notice_sent_on" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN pro_expiry_notice_sent_on DATE")
            if "email_verified_at" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN email_verified_at DATETIME")
            if "is_trial" not in user_cols:
                stmts.append("ALTER TABLE users ADD COLUMN is_trial BOOLEAN DEFAULT 0")
            if "tgo_store_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN tgo_store_id VARCHAR(50)")
            if "migros_group_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN migros_group_id VARCHAR(50)")
            if "migros_warehouse_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN migros_warehouse_id VARCHAR(50)")
            if "getir_restaurant_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN getir_restaurant_id VARCHAR(50)")
            if "getir_restaurant_name" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN getir_restaurant_name VARCHAR(120)")
            if "getir_restaurant_secret_key" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN getir_restaurant_secret_key VARCHAR(512)")
            if "tmp_supplier_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN tmp_supplier_id VARCHAR(50)")
            if "tmp_integration_ref" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN tmp_integration_ref VARCHAR(120)")
            if "tmp_api_key" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN tmp_api_key VARCHAR(512)")
            if "tmp_api_secret" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN tmp_api_secret VARCHAR(512)")
            if "hb_merchant_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN hb_merchant_id VARCHAR(80)")
            if "hb_username" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN hb_username VARCHAR(120)")
            if "hb_service_key" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN hb_service_key VARCHAR(512)")
            if "hb_environment" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN hb_environment VARCHAR(20) DEFAULT 'live'")
            if "hb_auto_packaging" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN hb_auto_packaging BOOLEAN DEFAULT FALSE")
            if "ys_chain_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_chain_id VARCHAR(100)")
            if "ys_store_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_store_id VARCHAR(100)")
            if "ys_vendor_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_vendor_id VARCHAR(100)")
            if "ys_environment" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_environment VARCHAR(20) DEFAULT 'live'")
            if "ys_client_id" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_client_id VARCHAR(512)")
            if "ys_client_secret" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN ys_client_secret VARCHAR(512)")
            if "notify_weekly_report" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN notify_weekly_report BOOLEAN DEFAULT TRUE")
            if "notify_monthly_report" not in intg_cols:
                stmts.append("ALTER TABLE integrations ADD COLUMN notify_monthly_report BOOLEAN DEFAULT TRUE")
            expense_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(platform_expenses)")).fetchall()} if conn.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name='platform_expenses'")).fetchone() else set()
            if expense_cols and "expense_type" not in expense_cols:
                stmts.append("ALTER TABLE platform_expenses ADD COLUMN expense_type VARCHAR(20) DEFAULT 'fixed'")
            order_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(orders)")).fetchall()} if conn.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name='orders'")).fetchone() else set()
            if order_cols and "active_hidden_at" not in order_cols:
                stmts.append("ALTER TABLE orders ADD COLUMN active_hidden_at DATETIME")
            for s in stmts:
                try:
                    conn.execute(text(s))
                except Exception as e:
                    print(f"[SCHEMA] atlandi: {s} -> {e}")
        return
    else:
        return

    with db.engine.begin() as conn:
        for s in stmts:
            try:
                conn.execute(text(s))
            except Exception as e:
                print(f"[SCHEMA] atlandi: {s} -> {e}")

def create_app(config_class=Config, start_scheduler=None):
    import monitoring
    monitoring.configure_logging()

    app = Flask(__name__)
    app.config.from_object(config_class)
    if not app.config.get("TESTING"):
        monitoring.init_sentry(app)

    # Reverse proxy (Railway/Render/Nginx) arkasında gerçek şema/host'u oku ki
    # url_for(_external=True) → https://siparisgeldi.net/... doğru üretilsin.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    # Eklentileri bağla
    db.init_app(app)
    login_manager.init_app(app)

    # Modeller (tablo kaydı için import şart)
    import models  # noqa: F401

    # Blueprint'ler
    from routes.public import public_bp
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.webhooks import webhooks_bp
    from routes.adisyo import adisyo_bp
    from routes.admin import admin_bp
    from routes.paytr import paytr_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp, url_prefix="/panel")
    app.register_blueprint(webhooks_bp, url_prefix="/webhooks")
    app.register_blueprint(adisyo_bp, url_prefix="/panel/adisyo")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(paytr_bp, url_prefix="/payment/paytr")

    # Şablonlarda kullanılacak yardımcılar
    from datetime import datetime
    import utils
    import profit_report

    from routes.admin import is_admin
    from flask_login import current_user

    def csrf_token():
        token = session.get("_csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
        return token

    @app.before_request
    def protect_forms():
        if request.method != "POST" or request.path.startswith("/webhooks/") or request.path == "/payment/paytr/callback":
            return None
        sent = request.form.get("_csrf_token") or request.headers.get("X-CSRF-Token", "")
        if not secrets.compare_digest(str(session.get("_csrf_token", "")), str(sent)):
            abort(400)
        return None

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if request.is_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return response

    @app.context_processor
    def inject_helpers():
        dashboard_latest_order_id = 0
        if current_user.is_authenticated and request.blueprint == "dashboard":
            from sqlalchemy import func
            from models import Order
            dashboard_latest_order_id = (
                db.session.query(func.max(Order.id))
                .filter_by(user_id=current_user.id)
                .scalar()
                or 0
            )
        return {
            "now": datetime.utcnow,
            "status_label": utils.status_label,
            "status_color": utils.status_color,
            "platform_label": utils.platform_label,
            "bot_username": app.config.get("TELEGRAM_BOT_USERNAME", ""),
            "user_is_admin": is_admin(current_user),
            "is_pro_user": lambda user=None: bool(getattr(user or current_user, "is_pro_active", False)),
            "user_can_whatsapp": lambda user=None: bool(getattr(user or current_user, "has_whatsapp_access", False)),
            "user_can_multi_platform": lambda user=None: bool(getattr(user or current_user, "has_multi_platform_access", False)),
            "company": {
                "legal_name": app.config.get("COMPANY_LEGAL_NAME", "SiparişGeldi"),
                "brand_name": app.config.get("COMPANY_BRAND_NAME", "SiparişGeldi"),
                "address": app.config.get("COMPANY_ADDRESS", ""),
                "phone": app.config.get("COMPANY_PHONE", ""),
                "email": app.config.get("COMPANY_EMAIL", ""),
                "tax_office": app.config.get("COMPANY_TAX_OFFICE", ""),
                "tax_number": app.config.get("COMPANY_TAX_NUMBER", ""),
            },
            "csrf_token": csrf_token,
            "trial_days": int(app.config.get("TRIAL_DAYS", 0) or 0),
            "tl_amount": profit_report.tl,
            "mail_configured": bool(app.config.get("SMTP_HOST")),
            "dashboard_latest_order_id": dashboard_latest_order_id,
        }

    # Tabloları oluştur + hafif şema güncellemeleri (mevcut Postgres'e yeni kolon)
    with app.app_context():
        db.create_all()
        _ensure_schema()

    # Arka plan zamanlayıcı (dev: web süreci içinde)
    should_start = app.config.get("RUN_SCHEDULER", True) if start_scheduler is None else start_scheduler
    if should_start:
        from worker import start_scheduler as _start
        _start(app)

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
